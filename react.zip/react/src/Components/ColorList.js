import React, { Component } from 'react'

 class ColorList extends Component {
     constructor(){
         super();
         this.state={
             color:[
                 {id:1,name:"red"},
                 {id:2,name:"black"},
                 {id:3,name:"green"}
             ]
         }
     }
    render() {
        return (
            <div>
                <div class="text-primary bg-info display-6">this is color list</div>
                <ol>
                    {
                        this.state.color.map((val)=>{
                            return<li>{val.name}</li>
                        })
                        
                    }
                </ol>
            </div>
        )
    }
}

export default ColorList
