import React, { Component } from 'react'

export class CbMouseOver extends Component {
    constructor(props){
        super(props);
        this.state={
            count:1
        }
       
    
        }
        incrementHandler= ()=>{
            this.setState(prevState=>{
                return{
                    count:prevState.count+1
                }
            })
        }
    render() {
        
        var{count}=this.state;
        return (
            <div>
                
                
                <p>MouseOver</p>
                <button type="button" onMouseOver={this.incrementHandler}>click{count} times</button>
            </div>
        )
    }
}

export default CbMouseOver











