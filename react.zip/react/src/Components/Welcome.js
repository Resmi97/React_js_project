import React from 'react'

function Welcome() {
    return <h3>This is function Component</h3>
}

export default Welcome

