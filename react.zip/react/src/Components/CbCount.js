import React, { Component } from 'react'

export class CbCount extends Component {

    constructor(props){
        super(props);
        this.state={
            count:1
        }
        /*setTimeout(() => this.setState({count:this.state.count+5 }),1000);
        setTimeout(() =>this.setState(prevState=>({count:prevState.count+10})),2000)*/
    
        }
        incrementHandler= ()=>{
            this.setState(prevState=>{
                return{
                    count:prevState.count+1
                }
            })
        }
    render() {
        var{user,post}=this.props;
        var{count}=this.state;
        return (
            <div>
                <h3>Welcome You {user} in react class</h3>
                <p>I am {post}</p>
                {/*<button type="button">click {count} times</button>*/}
                <button type="button" onClick={this.incrementHandler}>click{count} times</button>
            </div>
        )
    }
}

export default CbCount
