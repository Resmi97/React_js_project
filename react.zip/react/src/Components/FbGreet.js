import React from 'react'
/*function FbGreet(){
    return<h3>Welcome You all</h3>
} */
var FbGreet = (props)=>{
var {user,post}=props;

        return <div>
                 <h3>Welcome You {user}</h3>
                  <p>I am {post}</p>
        
            </div>
        } 

export default FbGreet
