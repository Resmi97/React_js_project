import React, { Component } from 'react'

 class Conditioalyrender extends Component {
     constructor(){
         super();
         this.state={
             isLogin:false
         }
     }
    render() {
        var msg=""
        if(this.state.isLogin){
            msg="Hello Admin";
        }else      
        {
            msg="Hello user";
        }  
        return !this.state.isLogin && (<h2>Hello Admin</h2>)
    }
}

export default Conditioalyrender
