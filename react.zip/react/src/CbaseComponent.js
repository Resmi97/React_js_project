import React, { Component } from 'react'

export class CbaseComponent extends Component {
    render() {
        return <h3>This is class Component</h3>
    }
}

export default CbaseComponent
