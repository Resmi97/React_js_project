import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import CbaseComponent from './CbaseComponent';
import FbGreet from './Components/FbGreet';
import CbCount from './Components/CbCount';
import CbMouseOver from './Components/CbMouseOver';
import Welcome from './Components/Welcome';
import ColorList from './Components/ColorList';
import 'bootstrap/dist/css/bootstrap.min.css';
import Conditioalyrender from './Components/Conditioalyrender';


ReactDOM.render(
  <React.StrictMode>
    <App />
    <Welcome/>
    <CbaseComponent/>
    <FbGreet user="Resmi" post="developer"/>
    <CbCount user="Resmi" post="developer"/>
    <CbMouseOver/>
    <ColorList/>
    <Conditioalyrender/>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
